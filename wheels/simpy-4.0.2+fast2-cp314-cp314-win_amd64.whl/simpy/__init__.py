"""
The ``simpy`` module aggregates SimPy's most used components into a single
namespace. This is purely for convenience. You can of course also access
everything (and more!) via their actual submodules.

The following tables list all the available components in this module.

{toc}

"""
try:
    from importlib.metadata import version as _dist_version
except ImportError:  # Python < 3.8
    from pkg_resources import get_distribution

    def _dist_version(name: str) -> str:
        return get_distribution(name).version
from pkgutil import extend_path
from typing import Tuple, Type

from simpy.core import Environment
from simpy.rt import RealtimeEnvironment
from simpy.exceptions import SimPyException, Interrupt
from simpy.events import Event, Timeout, Process, AllOf, AnyOf
from simpy.resources.resource import (
    Resource, PriorityResource, PreemptiveResource)
from simpy.resources.container import Container
from simpy.resources.store import (
    Store, PriorityItem, PriorityStore, FilterStore)

__all__ = [
    'AllOf',
    'AnyOf',
    'Container',
    'Environment',
    'Event',
    'FilterStore',
    'Interrupt',
    'PreemptiveResource',
    'PriorityItem',
    'PriorityResource',
    'PriorityStore',
    'Process',
    'RealtimeEnvironment',
    'Resource',
    'SimPyException',
    'Store',
    'Timeout',
]


def _compile_toc(
    entries: Tuple[Tuple[str, Tuple[Type, ...]], ...],
    section_marker: str = '=',
) -> str:
    """Compiles a list of sections with objects into sphinx formatted
    autosummary directives."""
    toc = ''
    for section, objs in entries:
        toc += '\n\n'
        toc += f'{section}\n'
        toc += f'{section_marker * len(section)}\n\n'
        toc += '.. autosummary::\n\n'
        for obj in objs:
            toc += f'    ~{obj.__module__}.{obj.__name__}\n'
    return toc


_toc = (
    ('Environments', (
        Environment, RealtimeEnvironment,
    )),
    ('Events', (
        Event, Timeout, Process, AllOf, AnyOf, Interrupt,
    )),
    ('Resources', (
        Resource, PriorityResource, PreemptiveResource, Container, Store,
        PriorityItem, PriorityStore, FilterStore,
    )),
    ('Exceptions', (
        SimPyException, Interrupt
    )),
)

# Use the _toc to keep the documentation and the implementation in sync.
if __doc__:
    __doc__ = __doc__.format(toc=_compile_toc(_toc))
    assert set(__all__) == {obj.__name__ for _, objs in _toc for obj in objs}

__path__ = list(extend_path(__path__, __name__))
__version__: str = _dist_version('simpy')
